import fssolib.fsaehandler as fsaehandler

fsaehandler.runServer(('0.0.0.0',8000),fsaehandler.FSAE_Handler)
